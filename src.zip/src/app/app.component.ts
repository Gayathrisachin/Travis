import { Component } from '@angular/core';
import { CountriesService } from './countries.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Task';
  selectedItems: any;
    items = [];
  stateInfo: any[] = [];
  // countryInfo: any[] = [];
  cityInfo: any[] = [];

  events: Event[] = [];
  constructor(private state:CountriesService) { }

  ngOnInit() {
    this.getCountries();
  }

  onChange($event) {
    this.events.push({ name: '(change)', value: $event });
}
  getCountries(){
    this.state.allCountries().
    subscribe(
      data2 => {
        this.stateInfo=data2;
        console.log('Data:', this.stateInfo);
      },
      err => console.log(err),
      () => console.log('complete')
    )
  }

  onChangeState(stateValue) {
    // this.stateInfo=this.countryInfo[countryValue].States;
    this.cityInfo=this.stateInfo[stateValue].districts;
    console.log("this is cities",this.cityInfo);
  }

  // onChangeState(stateValue) {
  //   this.cityInfo=this.stateInfo[stateValue].Cities;
  //   //console.log(this.cityInfo);
  // }
    

}
